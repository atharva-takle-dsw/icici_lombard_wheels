"""Uptrace distro version"""

__version__ = "1.27.0"
