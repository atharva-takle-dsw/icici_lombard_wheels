import sys

from queens import main

main()
